#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# TikTok OSINT Tool – Random Mobile Session + Email Logic
#Owner of the tool : AHM7D SALEEM
import requests
import re
import random

# ===== Colors =====
R = "\033[1;31m"
G = "\033[1;32m"
Y = "\033[1;33m"
W = "\033[1;37m"

# ===== Banner =====
banner = f"""{G}
████████╗██╗██╗  ██╗████████╗ ██████╗ ██╗  ██╗
╚══██╔══╝██║██║ ██╔╝╚══██╔══╝██╔═══██╗██║ ██╔╝
   ██║   ██║█████╔╝    ██║   ██║   ██║█████╔╝ ------AHM7D Sy
   ██║   ██║██╔═██╗    ██║   ██║   ██║██╔═██╗
   ██║   ██║██║  ██╗   ██║   ╚██████╔╝██║  ██╗
   ╚═╝   ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝

[{W} TikTok OSINT – User Info -AHM7D Sy {G}]
"""
print(banner)

# ===== Input =====
username = input(f"{Y}[ TikTok Username أو ID ] => {W}").strip()
if username.startswith("@"):
    username = username[1:]

# ===== Random Mobile User-Agents =====
mobile_agents = [
    # Android
    "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; Redmi Note 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",

    # iPhone
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 12_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
]

mobile_ua = random.choice(mobile_agents)

headers = {
    "User-Agent": mobile_ua
}

url = f"https://www.tiktok.com/@{username}"

try:
    r = requests.get(url, headers=headers, timeout=15).text

    user_id = re.search(r'"id":"(\d+)"', r)
    followers = re.search(r'"followerCount":(\d+)', r)
    following = re.search(r'"followingCount":(\d+)', r)
    videos = re.search(r'"videoCount":(\d+)', r)
    region = re.search(r'"region":"(\w+)"', r)
    nickname = re.search(r'"nickname":"(.*?)"', r)

    if not user_id:
        print(R + "[×] الحساب غير موجود أو محجوب")
        exit()

    # ===== Email Logic =====
    email_match = re.search(
        r'[a-zA-Z0-9._%+-]+@(gmail\.com|hotmail\.com)',
        r,
        re.IGNORECASE
    )

    if email_match:
        email = email_match.group(0)
        email_source = "FOUND"
    else:
        email = f"{user_id.group(1)}@gmail.com"
        email_source = "ID → GMAIL"

    info = f"""
Username   : @{username}
Nickname   : {nickname.group(1) if nickname else 'N/A'}
User ID    : {user_id.group(1)}
Followers  : {followers.group(1) if followers else '0'}
Following  : {following.group(1) if following else '0'}
Videos     : {videos.group(1) if videos else '0'}
Region     : {region.group(1) if region else 'N/A'}

Session    : Mobile
Device UA  : {mobile_ua.split(')')[0]})

Email      : {email}
Email Mode : {email_source}

Profile    : https://www.tiktok.com/@{username}
"""

    print(G + "\n[✓] تم جمع معلومات الحساب\n")
    print(W + info)

    with open("tiktok-user-info.txt", "a", encoding="utf-8") as f:
        f.write(info + "\n" + "-" * 40 + "\n")

except Exception as e:
    print(R + f"[×] خطأ: {e}")
